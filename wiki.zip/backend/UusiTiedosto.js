const fs = require('fs');

const tiedosto = process.argv[2];

try {
  const dataBuffer = fs.readFileSync(tiedosto);

  const data = dataBuffer.toString();
  console.log(data);
} catch (err) {
  console.error(err);
}

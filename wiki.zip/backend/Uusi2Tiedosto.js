fs = require('fs');

fs.writeFile('uusitiedosto.txt', ' Moikka Maailma ', function (err) {
    if (err) return console.log(err);
    console.log('Tallennus onnistui > uusi2Tiedosto.txt');
});